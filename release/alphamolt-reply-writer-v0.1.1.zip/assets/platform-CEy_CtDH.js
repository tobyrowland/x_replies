function c(o,n={}){const e=n.root??document,u=n.timeoutMs??5e3,r=e.querySelector(o);return r?Promise.resolve(r):new Promise(s=>{const t=new MutationObserver(()=>{const i=e.querySelector(o);i&&(t.disconnect(),s(i))});t.observe(e instanceof Document?e.body:e,{childList:!0,subtree:!0}),window.setTimeout(()=>{t.disconnect(),s(null)},u)})}export{c as w};
//# sourceMappingURL=platform-CEy_CtDH.js.map
